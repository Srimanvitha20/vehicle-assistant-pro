import React, { useState } from 'react';
import { Car, Users, Wrench, BarChart3, MapPin, Clock, CheckCircle, AlertTriangle } from 'lucide-react';
import Dashboard from './components/Dashboard';
import CustomerPortal from './components/CustomerPortal';
import AdminPanel from './components/AdminPanel';
import MechanicPanel from './components/MechanicPanel';
import AuthForm from './components/AuthForm';

export type UserRole = 'customer' | 'admin' | 'mechanic';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  phone?: string;
}

export interface ServiceRequest {
  id: string;
  customerId: string;
  customerName: string;
  vehicleDetails: string;
  location: string;
  description: string;
  status: 'pending' | 'assigned' | 'in-progress' | 'completed' | 'cancelled';
  priority: 'low' | 'medium' | 'high' | 'emergency';
  mechanicId?: string;
  mechanicName?: string;
  requestedAt: string;
  estimatedArrival?: string;
  completedAt?: string;
  cost?: number;
}

export interface Mechanic {
  id: string;
  name: string;
  phone: string;
  email: string;
  specialization: string;
  location: string;
  isAvailable: boolean;
  rating: number;
  completedJobs: number;
}

function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activeView, setActiveView] = useState<'dashboard' | 'requests' | 'mechanics' | 'analytics'>('dashboard');

  // Sample data - in a real app, this would come from an API
  const [serviceRequests, setServiceRequests] = useState<ServiceRequest[]>([
    {
      id: '1',
      customerId: 'c1',
      customerName: 'John Smith',
      vehicleDetails: '2020 Honda Civic - License: ABC123',
      location: 'Downtown Main Street, near City Mall',
      description: 'Engine won\'t start, possible battery issue',
      status: 'pending',
      priority: 'high',
      requestedAt: '2025-01-16T10:30:00Z'
    },
    {
      id: '2',
      customerId: 'c2',
      customerName: 'Sarah Johnson',
      vehicleDetails: '2019 Toyota Camry - License: XYZ789',
      location: 'Highway 101, Mile Marker 45',
      description: 'Flat tire, spare tire needed',
      status: 'assigned',
      priority: 'medium',
      mechanicId: 'm1',
      mechanicName: 'Mike Wilson',
      requestedAt: '2025-01-16T09:15:00Z',
      estimatedArrival: '2025-01-16T11:00:00Z'
    },
    {
      id: '3',
      customerId: 'c3',
      customerName: 'David Brown',
      vehicleDetails: '2021 Ford F-150 - License: DEF456',
      location: 'Oak Street Parking Garage, Level 2',
      description: 'Vehicle overheating, coolant leak suspected',
      status: 'in-progress',
      priority: 'high',
      mechanicId: 'm2',
      mechanicName: 'Lisa Anderson',
      requestedAt: '2025-01-16T08:45:00Z'
    }
  ]);

  const [mechanics, setMechanics] = useState<Mechanic[]>([
    {
      id: 'm1',
      name: 'Mike Wilson',
      phone: '(555) 123-4567',
      email: 'mike.wilson@assist.com',
      specialization: 'Engine & Electrical',
      location: 'Downtown District',
      isAvailable: false,
      rating: 4.8,
      completedJobs: 156
    },
    {
      id: 'm2',
      name: 'Lisa Anderson',
      phone: '(555) 234-5678',
      email: 'lisa.anderson@assist.com',
      specialization: 'General Repairs',
      location: 'North Side',
      isAvailable: false,
      rating: 4.9,
      completedJobs: 203
    },
    {
      id: 'm3',
      name: 'Carlos Rodriguez',
      phone: '(555) 345-6789',
      email: 'carlos.rodriguez@assist.com',
      specialization: 'Towing & Recovery',
      location: 'Highway Patrol',
      isAvailable: true,
      rating: 4.7,
      completedJobs: 89
    }
  ]);

  const handleLogin = (email: string, password: string, role: UserRole) => {
    // Simulate login - in a real app, this would validate against an API
    const user: User = {
      id: role === 'admin' ? 'admin1' : role === 'mechanic' ? 'm1' : 'c1',
      name: role === 'admin' ? 'Admin User' : role === 'mechanic' ? 'Mike Wilson' : 'John Smith',
      email,
      role,
      phone: role === 'mechanic' ? '(555) 123-4567' : '(555) 987-6543'
    };
    setCurrentUser(user);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setActiveView('dashboard');
  };

  const updateServiceRequest = (updatedRequest: ServiceRequest) => {
    setServiceRequests(prev => 
      prev.map(req => req.id === updatedRequest.id ? updatedRequest : req)
    );
  };

  const addServiceRequest = (newRequest: Omit<ServiceRequest, 'id'>) => {
    const request: ServiceRequest = {
      ...newRequest,
      id: Date.now().toString()
    };
    setServiceRequests(prev => [request, ...prev]);
  };

  if (!currentUser) {
    return <AuthForm onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="flex items-center justify-center w-10 h-10 bg-blue-600 rounded-lg">
                <Car className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">VehicleAssist Pro</h1>
                <p className="text-sm text-gray-500">Breakdown Management System</p>
              </div>
            </div>
            
            {currentUser.role === 'admin' && (
              <nav className="hidden md:flex space-x-8">
                <button
                  onClick={() => setActiveView('dashboard')}
                  className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    activeView === 'dashboard' 
                      ? 'bg-blue-100 text-blue-700' 
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                  }`}
                >
                  <BarChart3 className="w-4 h-4" />
                  <span>Dashboard</span>
                </button>
                <button
                  onClick={() => setActiveView('requests')}
                  className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    activeView === 'requests' 
                      ? 'bg-blue-100 text-blue-700' 
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                  }`}
                >
                  <AlertTriangle className="w-4 h-4" />
                  <span>Service Requests</span>
                </button>
                <button
                  onClick={() => setActiveView('mechanics')}
                  className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    activeView === 'mechanics' 
                      ? 'bg-blue-100 text-blue-700' 
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                  }`}
                >
                  <Users className="w-4 h-4" />
                  <span>Mechanics</span>
                </button>
              </nav>
            )}
            
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm font-medium text-gray-900">{currentUser.name}</p>
                <p className="text-xs text-gray-500 capitalize">{currentUser.role}</p>
              </div>
              <button
                onClick={handleLogout}
                className="bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded-md text-sm font-medium transition-colors"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {currentUser.role === 'customer' && (
          <CustomerPortal
            user={currentUser}
            userRequests={serviceRequests.filter(req => req.customerId === currentUser.id)}
            onAddRequest={addServiceRequest}
          />
        )}
        
        {currentUser.role === 'admin' && (
          <>
            {activeView === 'dashboard' && (
              <Dashboard 
                serviceRequests={serviceRequests}
                mechanics={mechanics}
              />
            )}
            {(activeView === 'requests' || activeView === 'mechanics') && (
              <AdminPanel
                activeView={activeView}
                serviceRequests={serviceRequests}
                mechanics={mechanics}
                onUpdateRequest={updateServiceRequest}
                onUpdateMechanic={(updatedMechanic) => {
                  setMechanics(prev => 
                    prev.map(mech => mech.id === updatedMechanic.id ? updatedMechanic : mech)
                  );
                }}
              />
            )}
          </>
        )}
        
        {currentUser.role === 'mechanic' && (
          <MechanicPanel
            mechanic={mechanics.find(m => m.id === currentUser.id)!}
            assignedRequests={serviceRequests.filter(req => req.mechanicId === currentUser.id)}
            onUpdateRequest={updateServiceRequest}
          />
        )}
      </main>
    </div>
  );
}

export default App;