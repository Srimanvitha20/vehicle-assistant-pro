import React, { useState } from 'react';
import { 
  Search, Filter, MoreVertical, User, MapPin, Clock, 
  Phone, Mail, Star, CheckCircle, XCircle, Edit, 
  UserPlus, Wrench
} from 'lucide-react';
import { ServiceRequest, Mechanic } from '../App';

interface AdminPanelProps {
  activeView: 'requests' | 'mechanics';
  serviceRequests: ServiceRequest[];
  mechanics: Mechanic[];
  onUpdateRequest: (request: ServiceRequest) => void;
  onUpdateMechanic: (mechanic: Mechanic) => void;
}

const AdminPanel: React.FC<AdminPanelProps> = ({
  activeView,
  serviceRequests,
  mechanics,
  onUpdateRequest,
  onUpdateMechanic
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [showAssignModal, setShowAssignModal] = useState<string | null>(null);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'text-yellow-600 bg-yellow-100';
      case 'assigned': return 'text-blue-600 bg-blue-100';
      case 'in-progress': return 'text-orange-600 bg-orange-100';
      case 'completed': return 'text-green-600 bg-green-100';
      case 'cancelled': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'emergency': return 'text-red-600 bg-red-100';
      case 'high': return 'text-orange-600 bg-orange-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'low': return 'text-green-600 bg-green-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const handleAssignMechanic = (requestId: string, mechanicId: string) => {
    const request = serviceRequests.find(req => req.id === requestId);
    const mechanic = mechanics.find(mech => mech.id === mechanicId);
    
    if (request && mechanic) {
      const updatedRequest: ServiceRequest = {
        ...request,
        status: 'assigned',
        mechanicId: mechanic.id,
        mechanicName: mechanic.name,
        estimatedArrival: new Date(Date.now() + 30 * 60 * 1000).toISOString() // 30 min from now
      };
      onUpdateRequest(updatedRequest);
      
      // Update mechanic availability
      onUpdateMechanic({ ...mechanic, isAvailable: false });
    }
    setShowAssignModal(null);
  };

  const updateRequestStatus = (requestId: string, newStatus: ServiceRequest['status']) => {
    const request = serviceRequests.find(req => req.id === requestId);
    if (request) {
      const updatedRequest: ServiceRequest = {
        ...request,
        status: newStatus,
        completedAt: newStatus === 'completed' ? new Date().toISOString() : request.completedAt
      };
      onUpdateRequest(updatedRequest);

      // If completing, free up the mechanic
      if (newStatus === 'completed' && request.mechanicId) {
        const mechanic = mechanics.find(m => m.id === request.mechanicId);
        if (mechanic) {
          onUpdateMechanic({ ...mechanic, isAvailable: true });
        }
      }
    }
  };

  const filteredRequests = serviceRequests.filter(request => {
    const matchesSearch = 
      request.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      request.vehicleDetails.toLowerCase().includes(searchTerm.toLowerCase()) ||
      request.location.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || request.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const filteredMechanics = mechanics.filter(mechanic =>
    mechanic.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    mechanic.specialization.toLowerCase().includes(searchTerm.toLowerCase()) ||
    mechanic.location.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (activeView === 'requests') {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Service Requests</h1>
          <p className="text-gray-600 mt-2">Manage and assign breakdown assistance requests</p>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input
                  type="text"
                  placeholder="Search requests..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Filter className="w-4 h-4 text-gray-400" />
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">All Status</option>
                <option value="pending">Pending</option>
                <option value="assigned">Assigned</option>
                <option value="in-progress">In Progress</option>
                <option value="completed">Completed</option>
                <option value="cancelled">Cancelled</option>
              </select>
            </div>
          </div>
        </div>

        {/* Requests List */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="p-6">
            <div className="space-y-4">
              {filteredRequests.map((request) => (
                <div key={request.id} className="border border-gray-200 rounded-lg p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h3 className="font-semibold text-gray-900">Request #{request.id}</h3>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getPriorityColor(request.priority)}`}>
                          {request.priority}
                        </span>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(request.status)}`}>
                          {request.status}
                        </span>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm font-medium text-gray-900">{request.customerName}</p>
                          <p className="text-sm text-gray-600">{request.vehicleDetails}</p>
                        </div>
                        <div className="flex items-start space-x-2">
                          <MapPin className="w-4 h-4 text-gray-400 mt-1 flex-shrink-0" />
                          <p className="text-sm text-gray-600">{request.location}</p>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {request.status === 'pending' && (
                        <button
                          onClick={() => setShowAssignModal(request.id)}
                          className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded text-sm font-medium transition-colors"
                        >
                          Assign
                        </button>
                      )}
                      {request.status === 'assigned' && (
                        <button
                          onClick={() => updateRequestStatus(request.id, 'in-progress')}
                          className="bg-orange-600 hover:bg-orange-700 text-white px-3 py-1 rounded text-sm font-medium transition-colors"
                        >
                          Start
                        </button>
                      )}
                      {request.status === 'in-progress' && (
                        <button
                          onClick={() => updateRequestStatus(request.id, 'completed')}
                          className="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded text-sm font-medium transition-colors"
                        >
                          Complete
                        </button>
                      )}
                    </div>
                  </div>
                  
                  <div className="mb-4">
                    <p className="text-sm font-medium text-gray-900 mb-1">Description</p>
                    <p className="text-sm text-gray-600">{request.description}</p>
                  </div>

                  {request.mechanicName && (
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                      <div className="flex items-center space-x-2">
                        <User className="w-4 h-4 text-blue-600" />
                        <span className="text-sm font-medium text-blue-900">Assigned to: {request.mechanicName}</span>
                      </div>
                      {request.estimatedArrival && (
                        <p className="text-sm text-blue-700 mt-1">
                          ETA: {new Date(request.estimatedArrival).toLocaleTimeString()}
                        </p>
                      )}
                    </div>
                  )}

                  <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-200">
                    <div className="flex items-center space-x-4">
                      <span className="text-sm text-gray-500">
                        Requested: {new Date(request.requestedAt).toLocaleString()}
                      </span>
                      {request.completedAt && (
                        <span className="text-sm text-gray-500">
                          Completed: {new Date(request.completedAt).toLocaleString()}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Assign Mechanic Modal */}
        {showAssignModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-xl shadow-lg max-w-md w-full">
              <div className="p-6 border-b border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900">Assign Mechanic</h3>
                <p className="text-sm text-gray-600 mt-1">Select an available mechanic for this request</p>
              </div>
              <div className="p-6">
                <div className="space-y-3">
                  {mechanics.filter(m => m.isAvailable).map((mechanic) => (
                    <button
                      key={mechanic.id}
                      onClick={() => handleAssignMechanic(showAssignModal, mechanic.id)}
                      className="w-full text-left p-4 border border-gray-200 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-colors"
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium text-gray-900">{mechanic.name}</p>
                          <p className="text-sm text-gray-600">{mechanic.specialization}</p>
                          <p className="text-sm text-gray-500">{mechanic.location}</p>
                        </div>
                        <div className="text-right">
                          <div className="flex items-center space-x-1">
                            <Star className="w-4 h-4 text-yellow-400" />
                            <span className="text-sm text-gray-600">{mechanic.rating}</span>
                          </div>
                          <p className="text-xs text-gray-500">{mechanic.completedJobs} jobs</p>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
                <div className="mt-6 flex space-x-3">
                  <button
                    onClick={() => setShowAssignModal(null)}
                    className="flex-1 px-4 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg font-medium transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // Mechanics view
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Mechanics Management</h1>
          <p className="text-gray-600 mt-2">Manage your team of mechanics and their availability</p>
        </div>
        <button className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium transition-colors">
          <UserPlus className="w-4 h-4" />
          <span>Add Mechanic</span>
        </button>
      </div>

      {/* Search */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input
            type="text"
            placeholder="Search mechanics..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      {/* Mechanics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredMechanics.map((mechanic) => (
          <div key={mechanic.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className="bg-blue-100 p-2 rounded-lg">
                  <Wrench className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">{mechanic.name}</h3>
                  <p className="text-sm text-gray-600">{mechanic.specialization}</p>
                </div>
              </div>
              <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                mechanic.isAvailable ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'
              }`}>
                {mechanic.isAvailable ? 'Available' : 'Busy'}
              </span>
            </div>

            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <Phone className="w-4 h-4 text-gray-400" />
                <span className="text-sm text-gray-600">{mechanic.phone}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Mail className="w-4 h-4 text-gray-400" />
                <span className="text-sm text-gray-600">{mechanic.email}</span>
              </div>
              <div className="flex items-center space-x-2">
                <MapPin className="w-4 h-4 text-gray-400" />
                <span className="text-sm text-gray-600">{mechanic.location}</span>
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-gray-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-1">
                  <Star className="w-4 h-4 text-yellow-400" />
                  <span className="text-sm font-medium text-gray-900">{mechanic.rating}/5</span>
                </div>
                <span className="text-sm text-gray-600">{mechanic.completedJobs} jobs completed</span>
              </div>
            </div>

            <div className="mt-4 flex space-x-2">
              <button
                onClick={() => onUpdateMechanic({ ...mechanic, isAvailable: !mechanic.isAvailable })}
                className={`flex-1 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                  mechanic.isAvailable
                    ? 'bg-red-100 text-red-700 hover:bg-red-200'
                    : 'bg-green-100 text-green-700 hover:bg-green-200'
                }`}
              >
                {mechanic.isAvailable ? 'Set Busy' : 'Set Available'}
              </button>
              <button className="px-3 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg text-sm font-medium transition-colors">
                <Edit className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminPanel;