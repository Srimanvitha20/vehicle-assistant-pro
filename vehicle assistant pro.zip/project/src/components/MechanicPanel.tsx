import React from 'react';
import { 
  MapPin, Clock, Phone, Car, CheckCircle, 
  AlertTriangle, Navigation, MessageSquare
} from 'lucide-react';
import { Mechanic, ServiceRequest } from '../App';

interface MechanicPanelProps {
  mechanic: Mechanic;
  assignedRequests: ServiceRequest[];
  onUpdateRequest: (request: ServiceRequest) => void;
}

const MechanicPanel: React.FC<MechanicPanelProps> = ({
  mechanic,
  assignedRequests,
  onUpdateRequest
}) => {
  const activeRequests = assignedRequests.filter(req => 
    req.status === 'assigned' || req.status === 'in-progress'
  );

  const completedToday = assignedRequests.filter(req => 
    req.status === 'completed' && 
    new Date(req.completedAt || '').toDateString() === new Date().toDateString()
  );

  const updateRequestStatus = (requestId: string, newStatus: ServiceRequest['status']) => {
    const request = assignedRequests.find(req => req.id === requestId);
    if (request) {
      const updatedRequest: ServiceRequest = {
        ...request,
        status: newStatus,
        completedAt: newStatus === 'completed' ? new Date().toISOString() : request.completedAt
      };
      onUpdateRequest(updatedRequest);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'assigned': return 'text-blue-600 bg-blue-100';
      case 'in-progress': return 'text-orange-600 bg-orange-100';
      case 'completed': return 'text-green-600 bg-green-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'emergency': return 'text-red-600 bg-red-100';
      case 'high': return 'text-orange-600 bg-orange-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'low': return 'text-green-600 bg-green-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Welcome, {mechanic.name}</h1>
        <p className="text-gray-600 mt-2">Manage your assigned service requests and track your progress</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Active Requests</p>
              <p className="text-3xl font-bold text-blue-600">{activeRequests.length}</p>
            </div>
            <div className="bg-blue-100 p-3 rounded-lg">
              <AlertTriangle className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Completed Today</p>
              <p className="text-3xl font-bold text-green-600">{completedToday.length}</p>
            </div>
            <div className="bg-green-100 p-3 rounded-lg">
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Completed</p>
              <p className="text-3xl font-bold text-gray-900">{mechanic.completedJobs}</p>
            </div>
            <div className="bg-gray-100 p-3 rounded-lg">
              <Car className="w-6 h-6 text-gray-600" />
            </div>
          </div>
          <div className="mt-4">
            <div className="flex items-center space-x-1">
              <span className="text-yellow-400">⭐</span>
              <span className="text-sm font-medium text-gray-900">{mechanic.rating}/5 Rating</span>
            </div>
          </div>
        </div>
      </div>

      {/* Active Requests */}
      {activeRequests.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900">Active Assignments</h2>
            <p className="text-gray-600 mt-1">Your current service requests</p>
          </div>
          <div className="p-6">
            <div className="space-y-6">
              {activeRequests.map((request) => (
                <div key={request.id} className="border border-gray-200 rounded-lg p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="bg-blue-100 p-2 rounded-lg">
                        <Car className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">Request #{request.id}</h3>
                        <p className="text-sm text-gray-600">{request.customerName}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${getPriorityColor(request.priority)}`}>
                        {request.priority}
                      </span>
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(request.status)}`}>
                        {request.status}
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <p className="text-sm font-medium text-gray-900 mb-1">Vehicle Details</p>
                      <p className="text-sm text-gray-600">{request.vehicleDetails}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-900 mb-1">Requested</p>
                      <p className="text-sm text-gray-600">
                        {new Date(request.requestedAt).toLocaleString()}
                      </p>
                    </div>
                  </div>

                  <div className="mb-4">
                    <p className="text-sm font-medium text-gray-900 mb-1">Location</p>
                    <div className="flex items-start space-x-2">
                      <MapPin className="w-4 h-4 text-gray-400 mt-1 flex-shrink-0" />
                      <p className="text-sm text-gray-600">{request.location}</p>
                    </div>
                  </div>

                  <div className="mb-4">
                    <p className="text-sm font-medium text-gray-900 mb-1">Problem Description</p>
                    <p className="text-sm text-gray-600">{request.description}</p>
                  </div>

                  {request.estimatedArrival && (
                    <div className="mb-4">
                      <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                        <div className="flex items-center space-x-2">
                          <Clock className="w-4 h-4 text-blue-600" />
                          <span className="text-sm font-medium text-blue-900">
                            Estimated Arrival: {new Date(request.estimatedArrival).toLocaleTimeString()}
                          </span>
                        </div>
                      </div>
                    </div>
                  )}

                  <div className="flex flex-wrap gap-3">
                    <button className="flex items-center space-x-2 bg-blue-100 hover:bg-blue-200 text-blue-700 px-4 py-2 rounded-lg text-sm font-medium transition-colors">
                      <Navigation className="w-4 h-4" />
                      <span>Get Directions</span>
                    </button>
                    
                    <button className="flex items-center space-x-2 bg-green-100 hover:bg-green-200 text-green-700 px-4 py-2 rounded-lg text-sm font-medium transition-colors">
                      <Phone className="w-4 h-4" />
                      <span>Call Customer</span>
                    </button>

                    <button className="flex items-center space-x-2 bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded-lg text-sm font-medium transition-colors">
                      <MessageSquare className="w-4 h-4" />
                      <span>Send Update</span>
                    </button>

                    {request.status === 'assigned' && (
                      <button
                        onClick={() => updateRequestStatus(request.id, 'in-progress')}
                        className="bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
                      >
                        Start Service
                      </button>
                    )}

                    {request.status === 'in-progress' && (
                      <button
                        onClick={() => updateRequestStatus(request.id, 'completed')}
                        className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
                      >
                        Mark Complete
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Today's Completed Jobs */}
      {completedToday.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900">Completed Today</h2>
            <p className="text-gray-600 mt-1">Jobs you've finished today</p>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {completedToday.map((request) => (
                <div key={request.id} className="flex items-center justify-between p-4 bg-green-50 border border-green-200 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                    <div>
                      <h3 className="font-medium text-gray-900">Request #{request.id}</h3>
                      <p className="text-sm text-gray-600">{request.customerName} - {request.vehicleDetails}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium text-green-700">Completed</p>
                    <p className="text-sm text-gray-600">
                      {request.completedAt && new Date(request.completedAt).toLocaleTimeString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* No Active Requests */}
      {activeRequests.length === 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <div className="p-8 text-center">
            <Car className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No Active Requests</h3>
            <p className="text-gray-600">You're all caught up! New assignments will appear here.</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default MechanicPanel;